data = read.csv("measurements.csv")


for (i in 1:length(data$unitsW)) {
  if(data$unitsW[i] == 'mm') {
    data$Limb.Width[i] = data$Limb.Width[i]/10
    data$unitsW[i] = 'cm'
  } else {
    print(Limb.Width)
  }
}


for (i in 1:length(data$unitsL)) {
  if(data$unitsL[i] == 'mm') {
    data$Limb.Length[i] = data$Limb.Length[i]/10
    data$unitsL[i] = 'cm'
  } else {
    print(Limb.Length)
  }
}

for (i in 1:data) {
    print(volume = pi*((data$unitsW[i]/2))^2*data$unitsL)
} 

data$volume = pi*((data$Limb.Width[i]/2)^2*data$Limb.Length)

library(ggplot2)

qplot(x = Limb.Width, y = Limb.Length, data = data, xlab = "Limb Width", 
      ylab = 'Limb Length')


